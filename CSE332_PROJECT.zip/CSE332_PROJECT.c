#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX_LEN 100

// Token types
typedef enum {
    NUMBER, PLUS, MINUS, TIMES, DIVIDE, LPAREN, RPAREN, END, INVALID
} TokenType;

// Token structure
typedef struct {
    TokenType type;
    char value[MAX_LEN];
} Token;

char *input;      // Global pointer to the input string
int position = 0;  // Current position in the input string

// Function declarations
Token getNextToken();
void parseExpression();
void parseTerm();
void parseFactor();
void error(const char *msg);
void expect(TokenType type);
void printToken(Token token);

// Function to get the next token from the input string
Token getNextToken() {
    Token token;
    while (input[position] != '\0' && isspace(input[position])) {
        position++;  // Skip white spaces
    }

    if (input[position] == '\0') {
        token.type = END;
        return token;
    }

    if (isdigit(input[position])) {
        int i = 0;
        while (isdigit(input[position])) {
            token.value[i++] = input[position++];
        }
        token.value[i] = '\0';
        token.type = NUMBER;
        return token;
    }

    if (input[position] == '+') {
        token.type = PLUS;
        token.value[0] = '+';
        token.value[1] = '\0';
        position++;
        return token;
    }
    if (input[position] == '-') {
        token.type = MINUS;
        token.value[0] = '-';
        token.value[1] = '\0';
        position++;
        return token;
    }
    if (input[position] == '*') {
        token.type = TIMES;
        token.value[0] = '*';
        token.value[1] = '\0';
        position++;
        return token;
    }
    if (input[position] == '/') {
        token.type = DIVIDE;
        token.value[0] = '/';
        token.value[1] = '\0';
        position++;
        return token;
    }
    if (input[position] == '(') {
        token.type = LPAREN;
        token.value[0] = '(';
        token.value[1] = '\0';
        position++;
        return token;
    }
    if (input[position] == ')') {
        token.type = RPAREN;
        token.value[0] = ')';
        token.value[1] = '\0';
        position++;
        return token;
    }

    // If no valid token found, return INVALID
    token.type = INVALID;
    token.value[0] = input[position];
    token.value[1] = '\0';
    return token;
}

// Function to print a token
void printToken(Token token) {
    switch (token.type) {
        case NUMBER:
            printf("NUMBER(%s)", token.value);
            break;
        case PLUS:
            printf("PLUS(+)");
            break;
        case MINUS:
            printf("MINUS(-)");
            break;
        case TIMES:
            printf("TIMES(*)");
            break;
        case DIVIDE:
            printf("DIVIDE(/)");
            break;
        case LPAREN:
            printf("LPAREN(()");
            break;
        case RPAREN:
            printf("RPAREN())");
            break;
        case END:
            printf("END");
            break;
        case INVALID:
            printf("INVALID(%s)", token.value);
            break;
    }
}

// Function to handle syntax errors
void error(const char *msg) {
    printf("Syntax Error: %s\n", msg);
    exit(1);
}

// Expect a specific token type
void expect(TokenType type) {
    Token token = getNextToken();
    if (token.type != type) {
        error("Unexpected token");
    }
    printToken(token);
    printf("\n");
}

// Function to parse an expression
void parseExpression() {
    parseTerm();
    Token token = getNextToken();
    while (token.type == PLUS || token.type == MINUS) {
        printToken(token);
        printf("\n");
        parseTerm();
        token = getNextToken();
    }
}

// Function to parse a term
void parseTerm() {
    parseFactor();
    Token token = getNextToken();
    while (token.type == TIMES || token.type == DIVIDE) {
        printToken(token);
        printf("\n");
        parseFactor();
        token = getNextToken();
    }
}

// Function to parse a factor
void parseFactor() {
    Token token = getNextToken();
    if (token.type == NUMBER) {
        printToken(token);
        printf("\n");
    }
    else if (token.type == LPAREN) {
        printToken(token);
        printf("\n");
        parseExpression();
        expect(RPAREN);
    }
    else {
        error("Unexpected token in factor");
    }
}

// Main function to start parsing the input
int main() {
    // Input string
    input = "3 + 4 * (2 - 1)";  // You can change this string to test other expressions

    printf("Parsing the expression: %s\n", input);

    parseExpression();  // Start parsing the expression

    Token token = getNextToken();
    if (token.type != END) {
        error("Extra characters at the end");
    }

    printf("Parsing completed successfully!\n");

    return 0;
}
